These files are not really "exercises", although that's what the Pluralsight site calls them. They contain two things:

1 - The slides of this training, in a more compact, non-animated form that you can use to review the content.
2 - The repository that I used in the screencast, copied after the end of each training module. You can use it to make your own experiments. Also, if you're like me, you'll find it much easier to remember the commands if you type them yourself.

I love feedback, so I hope to meet you on this training's discussion forum.
Have fun, and enjoy How Git Works!

   Paolo Perrotta
